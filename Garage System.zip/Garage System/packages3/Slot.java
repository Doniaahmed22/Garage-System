package packages3;

public class Slot {
	private int SlotID;
	private Dimensions dimensionslot;
	private Vehicle vehicle;

	public Slot(int SlotID, Dimensions dimensionslot) {
		this.SlotID = SlotID;
		this.dimensionslot = dimensionslot;
	}

	public Vehicle getVehicle() {
		return vehicle;
	}

	public void setVehicle(Vehicle vehicle) {
		this.vehicle = vehicle;
	}

	public Dimensions getDimensionslot() {
		return dimensionslot;
	}

	public void setDimensionslot(Dimensions dimensionslot) {
		this.dimensionslot = dimensionslot;
	}

	public int getSlotID() {
		return SlotID;
	}

	public void setSlotID(int slotID) {
		SlotID = slotID;
	}
}
