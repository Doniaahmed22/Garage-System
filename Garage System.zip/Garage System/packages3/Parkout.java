package packages3;

import java.time.Duration;
import java.time.LocalDateTime;

public class Parkout implements Park {

	public void park(Garage garage,Vehicle vehicle) {
		vehicle.setEndtime(LocalDateTime.now());
		Duration duration=Duration.between(vehicle.getStarttime(),vehicle.getEndtime());
		vehicle.setFees(duration.toMinutes()*5);
		garage.setTotalincome(garage.getTotalincome()+1);
		vehicle.getSlot().setVehicle(null);
	};
}
