package packages3;

import java.util.Iterator;

public class FirstFit implements ActiveSlot {
	public void WayOfParkingOfVehicle(Garage garage, Vehicle vehicle) {
		double w = vehicle.getDimensionvehicle().getWidth();
		double d = vehicle.getDimensionvehicle().getDepth();
		for (Iterator i = garage.getSlots().iterator(); i.hasNext();) {
			Slot slot = (Slot) i.next();
			if (w < slot.getDimensionslot().getWidth()
					&& d < slot.getDimensionslot().getDepth()
					&& slot.getVehicle() == null) {
				slot.setVehicle(vehicle);
				vehicle = null;
				break;
			}
		}
		if (vehicle != null)
			System.out.println("There is Not as Size of Your Vehicle ");
		else
			System.out.println("Successful");
	}
}
