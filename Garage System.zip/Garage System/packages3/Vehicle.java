package packages3;

import java.time.LocalDateTime;

public class Vehicle {
	private String ModelName;
	private String ModelYear;
	private String VehicleID;
	private Dimensions dimensionvehicle;
	private LocalDateTime Endtime;
	private LocalDateTime Starttime;
	private Driver driver;
	private double Fees;
	private Slot slot;
	
	public Vehicle(Driver driver)
	{
		this.driver=driver;
	}
	public String getModelName() {
		return ModelName;
	}


	public void setModelName(String modelName) {
		ModelName = modelName;
	}


	public String getModelYear() {
		return ModelYear;
	}


	public void setModelYear(String modelYear) {
		ModelYear = modelYear;
	}


	public String getVehicleID() {
		return VehicleID;
	}


	public void setVehicleID(String vehicleID) {
		VehicleID = vehicleID;
	}


	public Dimensions getDimensionvehicle() {
		return dimensionvehicle;
	}


	public void setDimensionvehicle(Dimensions dimensionvehicle) {
		this.dimensionvehicle = dimensionvehicle;
	}


	public LocalDateTime getEndtime() {
		return Endtime;
	}


	public void setEndtime(LocalDateTime endtime) {
		Endtime = endtime;
	}


	public LocalDateTime getStarttime() {
		return Starttime;
	}


	public void setStarttime(LocalDateTime starttime) {
		Starttime = starttime;
	}


	public Driver getDriver() {
		return driver;
	}


	public void setDriver(Driver driver) {
		this.driver = driver;
	}


	public double getFees() {
		return Fees;
	}


	public void setFees(double fees) {
		Fees = fees;
	}


	public Slot getSlot() {
		return slot;
	}


	public void setSlot(Slot slot) {
		this.slot = slot;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
