package packages3;

import java.util.Scanner;
import java.util.LinkedList;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List Drivers = new LinkedList();
		Scanner input = new Scanner(System.in);
		int number;
		double w,d;
		String S;
		Owner owner=new Owner();
		owner.Login();
		owner.SetUp();
		Parkin p=new Parkin();
		for (int i = 0; i < 3; i++)
		{
			Driver driver=new Driver();
			driver
			if(!Drivers.contains(driver))
			Drivers.add(driver);
			Vehicle v = new Vehicle(driver);
			System.out.println("Enter ModelYear :  ");
			S=input.nextLine();
			v.setModelYear(S);
			System.out.println("Enter ModelName :  ");
			S=input.nextLine();
			v.setModelName(S);
			System.out.println("Enter ID : ");
			S=input.nextLine();
			v.setVehicleID(S);
			System.out.println("Enter Width : ");
			w=input.nextFloat();
			System.out.println("Enter Depth : ");
			d=input.nextFloat();
			v.setDimensionvehicle(new Dimensions(w,d));
			p.park(garage,v);
		}
	}
}
