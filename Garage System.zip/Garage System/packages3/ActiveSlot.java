package packages3;

public interface ActiveSlot {
	 void WayOfParkingOfVehicle(Garage garage, Vehicle vehicle);
}
