package packages3;

import java.util.Iterator;

public class AdminScreen {
	public void displayNoslots(Garage garage) {
		System.out.println(" Number Of Slots in This Garage : "
				+ garage.getNoslots());
	}

	public void displayTotalincome(Garage garage) {
		System.out.println(" Income : "
				+ garage.getTotalincome());

	}

	public void DisplayAvailableSlots(Garage g) {
		System.out.println(" -> Display Available Slots ");
		for (Iterator i = g.getSlots().iterator(); i.hasNext();) {
			Slot s = (Slot) i.next();
			if (s.getVehicle() == null) {
				System.out.println(" Slot ");
				System.out.print(" Width : ");
				System.out.println(s.getDimensionslot().getWidth());
				System.out.print(" Depth : ");
				System.out.println(s.getDimensionslot().getDepth());
			}
		}
	}
}
