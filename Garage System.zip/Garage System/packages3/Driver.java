package packages3;

import java.util.Scanner;

public class Driver extends User {
	private String Address;
	private String Email;
	private int Phone;

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public int getPhone() {
		return Phone;
	}

	public void setPhone(int phone) {
		Phone = phone;
	}

	public void Login() {
		Scanner input = new Scanner(System.in);
		String S;
		int phone;
		System.out.print("Enter Name : ");
		S = input.nextLine();
		this.setName(S);
		System.out.print("Enter Password : ");
		S = input.nextLine();
		this.setPassword(S);
		System.out.print("Enter Address : ");
		S = input.nextLine();
		this.setAddress(S);
		System.out.print("Enter Email : ");
		S = input.nextLine();
		this.setEmail(S);
		System.out.print("Enter phone : ");
		phone = input.nextInt();
		this.setPhone(phone);
	}
}
