package packages3;

import java.util.Scanner;

public class Owner extends User {
	Garage garage;

	public void Login() {
		Scanner input = new Scanner(System.in);
		String S;
		System.out.print("Enter Name : ");
		S = input.nextLine();
		this.setName(S);
		System.out.print("Enter Password : ");
		S = input.nextLine();
		this.setPassword(S);
	}

	public void SetUp() {
		Scanner input = new Scanner(System.in);
		int NumberSlots, number;
		float w, d;
		int ID;
		System.out.print("Enter Number of Slots in Your Garage : ");
		NumberSlots = input.nextInt();
		Garage garage = new Garage();
		garage.setNoslots(NumberSlots);
		for (int i = 0; i < NumberSlots; i++) {
			System.out.println("Enter Slot " + (i + 1) + " Information ");
			System.out.print("Enter Slot ID : ");
			ID = input.nextInt();
			System.out.print("Enter Width : ");
			w = input.nextFloat();
			System.out.print("Enter depth : ");
			d = input.nextFloat();
			Dimensions dimensions = new Dimensions(w, d);
			Slot slot = new Slot(ID, dimensions);
			garage.AddSlot(slot);
		}
		System.out.println("Menu of Ways ");
		System.out.println(" 1 - First Fit ");
		System.out.println(" 2 - Best Fit ");
		System.out.print("Enter Number of  Way of Distribution Vehicles : ");
		number = input.nextInt();
		if (number == 1) {
			ActiveSlot activeslot = new FirstFit();
			garage.setActiveslot(activeslot);
		} else if (number == 2) {
			ActiveSlot activeslot = new BestFit();
			garage.setActiveslot(activeslot);
		} else {
			System.out.println("Error");
		}
		this.garage = garage;
	}
}
