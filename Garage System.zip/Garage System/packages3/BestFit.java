package packages3;

import java.util.Iterator;

public class BestFit implements ActiveSlot {
	public void WayOfParkingOfVehicle(Garage garage, Vehicle vehicle) {
		double wV = vehicle.getDimensionvehicle().getWidth();
		double dV = vehicle.getDimensionvehicle().getDepth();
		double wS = 100000;
		double dS = 100000;
		Slot s = null;
		for (Iterator i = garage.getSlots().iterator(); i.hasNext();) {
			Slot slot = (Slot) i.next();
			if (wV * dV < slot.getDimensionslot().getWidth()
					* slot.getDimensionslot().getWidth()
					&& slot.getVehicle() == null
					&& wS * dS > slot.getDimensionslot().getWidth()
							* slot.getDimensionslot().getDepth()) {
				wS = slot.getDimensionslot().getWidth();
				dS = slot.getDimensionslot().getDepth();
				s = slot;
			}
		}
		if (s.getVehicle() == null) {
			s.setVehicle(vehicle);
			System.out.println("Successful");
		} else
			System.out.println("There is Not as Size of Your Vehicle ");
	}
}
