package packages3;

import java.util.Iterator;

public class DriverScreen {

	public void displayFees(Vehicle v) {
		System.out.println(" Fees : "+ v.getFees());
	}
	public void DisplayAvailableSlots(Garage g) {
		System.out.println(" -> Display Available Slots ");
		for (Iterator i = g.getSlots().iterator(); i.hasNext();) {
			Slot s = (Slot) i.next();
			if (s.getVehicle() == null) {
				System.out.println(" Slot ");
				System.out.print(" Width : ");
				System.out.println(s.getDimensionslot().getWidth());
				System.out.print(" Depth : ");
				System.out.println(s.getDimensionslot().getDepth());
			}
		}
	}
	public void DisplaySlotsDimensions(Vehicle vehicle)
	{
		System.out.println("Slot");
		System.out.println("SlotID : "+vehicle.getSlot().getSlotID());
		System.out.println("Width  : "+vehicle.getSlot().getDimensionslot().getWidth());
		System.out.println("Depth  : "+vehicle.getSlot().getDimensionslot().getDepth());
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
