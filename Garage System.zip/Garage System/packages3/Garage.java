package packages3;

import java.util.LinkedList;
import java.util.List;

public class Garage {
	private int Noslots;
	private int NoVehicles;
	private double Totalincome;
	private List Slots = new LinkedList();
	private ActiveSlot activeslot;

	public void AddSlot(Slot slot) {
		Slots.add(slot);
	}

	public int getNoslots() {
		return Noslots;
	}

	public void setNoslots(int noslots) {
		Noslots = noslots;
	}

	public int getNoVehicles() {
		return NoVehicles;
	}

	public void setNoVehicles(int noVehicles) {
		NoVehicles = noVehicles;
	}

	public double getTotalincome() {
		return Totalincome;
	}

	public void setTotalincome(double totalincome) {
		Totalincome = totalincome;
	}

	public List getSlots() {
		return Slots;
	}

	public void setSlots(List slots) {
		Slots = slots;
	}

	public ActiveSlot getActiveslot() {
		return activeslot;
	}

	public void setActiveslot(ActiveSlot activeslot) {
		this.activeslot = activeslot;
	}
}
