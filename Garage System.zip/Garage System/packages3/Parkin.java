package packages3;

import java.time.LocalDateTime;

public class Parkin implements Park {
	public void park(Garage garage, Vehicle vehicle) {
		vehicle.setStarttime(LocalDateTime.now());
		garage.setNoVehicles(garage.getNoVehicles() + 1);
	};
}
