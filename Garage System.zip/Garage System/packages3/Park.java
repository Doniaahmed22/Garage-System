package packages3;

public interface Park {
    void park(Garage garage,Vehicle vehicle);
}
